import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.TestInstance;


public class KongaWebOrderTest {

    //import Selenium WebDriver
    private WebDriver driver;

    @BeforeTest
    public void setup() throws InterruptedException {

        //locate Chrome Driver
        System.setProperty("webdriver.chrome.driver", "resources/chromedriver-win64/chromedriver.exe");

        // Create ChromeOptions to configure browser preferences
        //1. Pass the ChromeOptions to the ChromeDriver
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");

        //Open chrome browser
        driver = new ChromeDriver(options);

        //1. input konga page url (https://www.konga.com/)
        driver.get("https://www.konga.com/");
        Thread.sleep(5000);

        //Maximise page
        driver.manage().window().maximize();
        Thread.sleep(3000);

    }

    @Test(priority = 0)
    public void login() throws InterruptedException {

        //2. Click on login to open the sign-in page
        driver.findElement(By.xpath("//*[@id=\"nav-bar-fix\"]/div[1]/div/div/div[4]/a")).click();
        Thread.sleep(3000);

        //2a. input username (email address) in the email field
        driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("");
        Thread.sleep(3000);

        //2b. input password in the password field
        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("");
        Thread.sleep(3000);

        //2c. click on login
        driver.findElement(By.xpath("//*[@id=\"app-content-wrapper\"]/div[4]/section/section/aside/div[2]/div/form/div[3]/button")).click();
        Thread.sleep(3000);
        System.out.println("login to konga successfully");
    }

    @Test(priority = 1)
    public void laptopcategory() throws InterruptedException {

        //3. click on All categories
        driver.findElement(By.xpath("//*[@id=\"nav-bar-fix\"]/div[2]/div/a[1]")).click();
        Thread.sleep(3000);

        //3a. select Computers and Accessories
        driver.findElement(By.xpath("//*[@id=\"nav-bar-fix\"]/div[2]/div/a[2]")).click();
        Thread.sleep(3000);

        //3b. select laptop
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/section[3]/section/div/section/div[2]/div[2]/ul/li[3]/a/label/span")).click();
        Thread.sleep(2000);
        System.out.println("click on laptop");

    }

    @Test (priority = 2)
    public void MacBook() throws InterruptedException {

        //4. select Macbook
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/section[3]/section/div/section/div[2]/div[2]/ul/li[3]/a/ul/li[1]/a/label/span")).click();
        Thread.sleep(2000);
        System.out.println("click on Apple Macbook");

    }

    @Test(priority = 3)
    public void itemtocart() throws InterruptedException {

        //5. select item and add to cart
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/section[3]/section/section/section/section/ul/li[40]/div/div/div[2]/form/div[3]/button")).click();
        Thread.sleep(3000);
        System.out.println("add item to cart");

        //5b. view cart
        driver.findElement(By.xpath("//*[@id=\"nav-bar-fix\"]/div[1]/div/div/a[2]/span[1]")).click();
        Thread.sleep(2000);

        //5c.checkout
        driver.findElement(By.xpath("//*[@id=\"app-content-wrapper\"]/div[3]/section/section/aside/div[3]/div/div[2]/button")).click();
        Thread.sleep(4000);

    }

    @Test(priority = 4)
    public void selectAddress() throws InterruptedException {

        //6. change address
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[1]/div/div/div[1]/div[2]/div/button")).click();
        Thread.sleep(5000);

        //6b. Add delivery Address to open the address book
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[1]/div/div/div[2]/div[1]/div[2]/div[1]/div/button")).click();
        Thread.sleep(5000);

        //6c. select Address
        driver.findElement(By.xpath("//*[@id=\"app-content-wrapper\"]/div[2]/section/section/aside/div[2]/div/div/div[2]/div[2]/form/button")).click();
        Thread.sleep(3000);

        //6d. use Address
        driver.findElement(By.xpath("//*[@id=\"app-content-wrapper\"]/div[2]/section/section/aside/div[3]/div/div/div/a")).click();
        Thread.sleep(3000);
        System.out.println("select address");

    }

    @Test(priority = 5)
    public void makepayment() throws InterruptedException {

        //7.Payment option
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[2]/div/div[2]/div[1]/div[1]/span/input")).click();
        Thread.sleep(2000);

        //7a. Payment Now option
        driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[2]/div/div[2]/div[1]/div[1]/h2")).click();
        Thread.sleep(4000);

         //7b. continue to payment
         driver.findElement(By.xpath("//*[@id=\"mainContent\"]/div/form/div/div[1]/section[2]/div/div[2]/div[3]/div[2]/div/button")).click();
         Thread.sleep(4000);
         System.out.println("make payment");

    }

    @Test (priority = 6)
    public void cardpayment() throws InterruptedException {

        //8. select card payment option
        //8a. change from default to iframe
        WebElement paymethod = driver.findElement(By.tagName("iframe"));

        driver.switchTo().frame("kpg-frame-component");
        Thread.sleep(5000);

         //8b. select card payment method
         WebElement cardpayment = driver.findElement(By.className("Card"));
         cardpayment.click();
         Thread.sleep(5000);
         System.out.println("select card method");

    }

    @Test (priority = 7)
    public void carddetails() throws InterruptedException {

        //9. input card digits
         WebElement carddigit = driver.findElement(By.id("card-number"));carddigit.sendKeys("53554455667890");
         Thread.sleep(3000);

        //9b. input date
        driver.findElement(By.xpath("//*[@id=\"expiry\"]")).click();
        WebElement datedigit = driver.findElement(By.id("expiry"));datedigit.sendKeys("0826");
        Thread.sleep(3000);

        //9c. input CVV
        WebElement cvvdigit = driver.findElement(By.id("cvv"));cvvdigit.sendKeys("123");
        Thread.sleep(5000);
        System.out.println("input card details");

    }

    @Test (priority = 8)
    public void errormessage() throws InterruptedException {

         //10. print out the error message
        WebElement error = driver.findElement(By.xpath("//*[@id=\"card-exists--false\"]/div[1]"));
        System.out.println(error.getText());
        Thread.sleep(5000);

        //11. close the Iframe that displays input card details
         WebElement exitframe = driver.findElement(By.className("data-card__close"));exitframe.click();
         System.out.println("exit iframe");
         Thread.sleep(5000);

    }

    @Test (priority = 9)
    public void exitiframe() throws InterruptedException {

            //12.  Exit iframe web
            driver.switchTo().defaultContent();
            Thread.sleep(5000);
            System.out.println("restore default");

    }

    @AfterTest
    public void Closebrowser() {
        //quit browser
        driver.quit();
    }
}








